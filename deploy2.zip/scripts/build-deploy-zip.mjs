import { createWriteStream, statSync } from "node:fs";
import { readdir, stat, readFile } from "node:fs/promises";
import { join, relative, sep, posix } from "node:path";
import { createDeflateRaw } from "node:zlib";
import { pipeline } from "node:stream/promises";
import { Readable } from "node:stream";
import { createHash } from "node:crypto";

const ROOT = process.cwd();
const OUT = process.argv[2] || "/tmp/deploy.zip";

const EXCLUDE_DIRS = new Set([
  "node_modules",
  ".git",
  ".cache",
  ".config",
  ".local",
  ".agents",
  "dist",
  ".turbo",
  ".next",
  "screenshots",
  "attached_assets",
]);
const EXCLUDE_PREFIXES = [".git.backup."];
const EXCLUDE_FILES = new Set(["zipFile.zip"]);
const EXCLUDE_EXT = new Set([".tsbuildinfo"]);

async function* walk(dir) {
  const entries = await readdir(dir, { withFileTypes: true });
  for (const e of entries) {
    const full = join(dir, e.name);
    if (e.isDirectory()) {
      if (EXCLUDE_DIRS.has(e.name)) continue;
      if (EXCLUDE_PREFIXES.some((p) => e.name.startsWith(p))) continue;
      yield* walk(full);
    } else if (e.isFile()) {
      if (EXCLUDE_FILES.has(e.name)) continue;
      const dot = e.name.lastIndexOf(".");
      const ext = dot >= 0 ? e.name.slice(dot) : "";
      if (EXCLUDE_EXT.has(ext)) continue;
      yield full;
    }
  }
}

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++)
    c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function dosTime(d) {
  return (
    ((d.getHours() & 0x1f) << 11) |
    ((d.getMinutes() & 0x3f) << 5) |
    ((d.getSeconds() / 2) & 0x1f)
  );
}
function dosDate(d) {
  return (
    (((d.getFullYear() - 1980) & 0x7f) << 9) |
    (((d.getMonth() + 1) & 0xf) << 5) |
    (d.getDate() & 0x1f)
  );
}

async function deflateRaw(buf) {
  const chunks = [];
  await pipeline(Readable.from([buf]), createDeflateRaw({ level: 9 }), async function* (src) {
    for await (const c of src) chunks.push(c);
  });
  return Buffer.concat(chunks);
}

async function main() {
  const out = createWriteStream(OUT);
  let offset = 0;
  const central = [];
  let totalIn = 0;
  let totalOut = 0;

  for await (const file of walk(ROOT)) {
    const rel = relative(ROOT, file).split(sep).join(posix.sep);
    const data = await readFile(file);
    totalIn += data.length;
    let method = 8;
    let compressed = await deflateRaw(data);
    if (compressed.length >= data.length) {
      method = 0;
      compressed = data;
    }
    totalOut += compressed.length;
    const crc = crc32(data);
    const st = statSync(file);
    const dt = st.mtime;
    const time = dosTime(dt);
    const date = dosDate(dt);
    const nameBuf = Buffer.from(rel, "utf8");

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6); // utf8 flag
    local.writeUInt16LE(method, 8);
    local.writeUInt16LE(time, 10);
    local.writeUInt16LE(date, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(compressed.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    local.writeUInt16LE(0, 28);

    out.write(local);
    out.write(nameBuf);
    out.write(compressed);
    const localOffset = offset;
    offset += local.length + nameBuf.length + compressed.length;

    const c = Buffer.alloc(46);
    c.writeUInt32LE(0x02014b50, 0);
    c.writeUInt16LE(20, 4);
    c.writeUInt16LE(20, 6);
    c.writeUInt16LE(0x0800, 8);
    c.writeUInt16LE(method, 10);
    c.writeUInt16LE(time, 12);
    c.writeUInt16LE(date, 14);
    c.writeUInt32LE(crc, 16);
    c.writeUInt32LE(compressed.length, 20);
    c.writeUInt32LE(data.length, 24);
    c.writeUInt16LE(nameBuf.length, 28);
    c.writeUInt16LE(0, 30);
    c.writeUInt16LE(0, 32);
    c.writeUInt16LE(0, 34);
    c.writeUInt16LE(0, 36);
    c.writeUInt32LE(0, 38);
    c.writeUInt32LE(localOffset, 42);
    central.push(Buffer.concat([c, nameBuf]));
  }

  const centralStart = offset;
  for (const c of central) {
    out.write(c);
    offset += c.length;
  }
  const centralSize = offset - centralStart;

  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(central.length, 8);
  end.writeUInt16LE(central.length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(centralStart, 16);
  end.writeUInt16LE(0, 20);
  out.write(end);
  await new Promise((r) => out.end(r));

  const finalSize = statSync(OUT).size;
  console.log(JSON.stringify({
    out: OUT,
    files: central.length,
    rawBytes: totalIn,
    deflatedBytes: totalOut,
    zipBytes: finalSize,
    rawMB: +(totalIn / 1024 / 1024).toFixed(2),
    zipMB: +(finalSize / 1024 / 1024).toFixed(2),
  }, null, 2));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
