# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Project: Insta Profile Analyzer

Russian-language tool that classifies Instagram profiles into a 16-bucket category map (1.1–4.4 plus "5 Убранные") based on visual analysis.

### Artifacts

- `artifacts/insta-analyzer` (web, `/`) — React + Vite UI. Textarea input → concurrent (max 2) `analyzeProfile` mutations → live grouping by category with copy-links / export-all per bucket. Russian dark theme.
- `artifacts/api-server` (api, `/api`) — Express server with:
  - `GET /api/healthz`
  - `GET /api/categories` → `CATEGORY_MAP` (16 buckets)
  - `POST /api/analyze` → captures 4K screenshots of `https://insta-stories-viewer.com/{username}/` via Playwright (3840x2160 viewport, full-page + top JPEG), sends them to OpenAI vision (`gpt-5.4`, JSON response_format) with the full category-rules prompt, returns `{username, instagramUrl, sourceUrl, category, subcategory, categoryName, summary, details, screenshots[]}`. Optional per-request proxy via `proxyServer` / `proxyUsername` / `proxyPassword` (HTTP/HTTPS/SOCKS5; `host:port` defaults to http).
  - `POST /api/proxy-test` → probes `https://api.ipify.org` through the supplied proxy and returns `{ ok, ip?, error? }`.

### V2-only UI features

- `artifacts/classification-engine-v2/src/pages/home.tsx` (only V2): proxy section in Advanced settings (checkbox + single `host:port` field + login + password + Проверить button), Stop button while a run is in progress (uses one shared `AbortController`; cancels in-flight fetches and marks queued tasks as "Отменено"). Proxy settings persist per editable preset in `data/presets.json`.

### Key files

- `lib/api-spec/openapi.yaml` — OpenAPI source for hooks/zod codegen.
- `artifacts/api-server/src/lib/categories.ts` — `CATEGORY_MAP`, `normalizeCategoryId`, `getCategoryName`.
- `artifacts/api-server/src/lib/screenshots.ts` — Playwright capture. Reuses one browser via `getBrowser()`. Uses `REPLIT_PLAYWRIGHT_CHROMIUM_EXECUTABLE` for the Nix-managed chromium.
- `artifacts/api-server/src/lib/analyze-vision.ts` — System prompt encoding all category rules + OpenAI call.
- `artifacts/api-server/src/routes/analyze.ts` — request validation + orchestration.
- `lib/integrations-openai-ai-server` — OpenAI client (uses `AI_INTEGRATIONS_OPENAI_BASE_URL` / `AI_INTEGRATIONS_OPENAI_API_KEY`).
- `artifacts/insta-analyzer/src/pages/home.tsx` — main UI.

### System dependencies

- Nix `playwright` package installed (provides chromium + system libs). Without it, headless-shell errors with `libglib-2.0.so.0: cannot open shared object file`.
