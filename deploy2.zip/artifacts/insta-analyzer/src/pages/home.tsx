import { useState, useEffect, useRef, useMemo } from "react";
import * as XLSX from "xlsx";
import {
  useAnalyzeProfile,
  useListCategories,
  useListPresets,
  useSavePresets,
  useResetPreset,
  type AnalyzeResult,
  type Preset,
  type PresetAdvanced,
  type PresetFlags,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ChevronDown, ChevronRight, Copy, Download, Loader2, CheckCircle2, XCircle, Clock, FileText, FileSpreadsheet, FileCode, Camera, RotateCcw, Lock } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Task {
  id: string;
  username: string;
  status: 'queued' | 'running' | 'done' | 'error';
  withPhotos: boolean;
  result?: AnalyzeResult;
  error?: string;
}

const FALLBACK_ADV: PresetAdvanced = {
  gotoTimeoutSeconds: 45,
  networkIdleTimeoutSeconds: 0,
  consentVisibilityMs: 500,
  consentClickMs: 2000,
  defaultTimeoutSeconds: 45,
  viewportWidth: 1600,
  viewportHeight: 3200,
  jpegQuality: 85,
};

const FALLBACK_FLAGS: PresetFlags = {
  autoScroll: false,
  disableLazyLoad: false,
  waitForNetworkIdle: false,
  waitForImagesComplete: false,
};

export default function Home() {
  const [input, setInput] = useState("");
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [advOpen, setAdvOpen] = useState(false);

  const { data: categories } = useListCategories();
  const { data: presetsState, refetch: refetchPresets } = useListPresets();
  const savePresetsMut = useSavePresets();
  const resetPresetMut = useResetPreset();
  const analyzeProfile = useAnalyzeProfile();

  const allPresets = useMemo<Preset[]>(() => {
    if (!presetsState) return [];
    return [presetsState.default, ...presetsState.editable];
  }, [presetsState]);

  const [selectedId, setSelectedId] = useState<string>("default");
  const [concurrency, setConcurrency] = useState(5);
  const [screenshotDelay, setScreenshotDelay] = useState(32);
  const [adv, setAdv] = useState<PresetAdvanced>(FALLBACK_ADV);
  const [flags, setFlags] = useState<PresetFlags>(FALLBACK_FLAGS);
  const hydratedRef = useRef(false);
  const lastLoadedIdRef = useRef<string>("");

  // When presets arrive or user changes selection — load values into local state.
  useEffect(() => {
    if (!presetsState) return;
    const target = allPresets.find(p => p.id === selectedId) ?? presetsState.default;
    if (lastLoadedIdRef.current === target.id && hydratedRef.current) return;
    setConcurrency(target.concurrency);
    setScreenshotDelay(target.screenshotDelaySeconds);
    setAdv({ ...target.adv });
    setFlags({ ...target.flags });
    lastLoadedIdRef.current = target.id;
    hydratedRef.current = true;
  }, [presetsState, selectedId, allPresets]);

  const selectedPreset = allPresets.find(p => p.id === selectedId);
  const isReadOnlyPreset = selectedPreset?.readOnly ?? true;

  // Debounced auto-save when local values diverge from saved editable preset
  useEffect(() => {
    if (!presetsState) return;
    if (!hydratedRef.current) return;
    if (isReadOnlyPreset) return;
    const target = presetsState.editable.find(p => p.id === selectedId);
    if (!target) return;
    const next: Preset = {
      ...target,
      concurrency,
      screenshotDelaySeconds: screenshotDelay,
      adv: { ...adv },
      flags: { ...flags },
    };
    if (JSON.stringify(next) === JSON.stringify(target)) return;

    const handle = setTimeout(() => {
      const editable = presetsState.editable.map(p => p.id === selectedId ? next : p);
      savePresetsMut.mutate({ data: { editable } }, {
        onSuccess: () => { refetchPresets(); },
      });
    }, 600);
    return () => clearTimeout(handle);
  }, [concurrency, screenshotDelay, adv, flags, selectedId, isReadOnlyPreset, presetsState, savePresetsMut, refetchPresets]);

  const handleResetCurrent = () => {
    if (isReadOnlyPreset) return;
    resetPresetMut.mutate({ id: selectedId }, {
      onSuccess: (state) => {
        const target = state.editable.find(p => p.id === selectedId);
        if (target) {
          setConcurrency(target.concurrency);
          setScreenshotDelay(target.screenshotDelaySeconds);
          setAdv({ ...target.adv });
          setFlags({ ...target.flags });
          lastLoadedIdRef.current = target.id;
        }
        refetchPresets();
      },
    });
  };

  const runAnalysis = async (withPhotos: boolean) => {
    if (!input.trim()) return;

    const rawLines = input.split('\n').map(l => l.trim()).filter(Boolean);
    const usernames = rawLines.map(line => {
      let clean = line.replace(/https?:\/\/(www\.)?instagram\.com\//i, '');
      clean = clean.split('?')[0];
      clean = clean.replace(/[/@]/g, '').trim();
      return clean;
    }).filter(Boolean);

    if (usernames.length === 0) return;

    const newTasks: Task[] = usernames.map(u => ({
      id: Math.random().toString(36).substr(2, 9),
      username: u,
      status: 'queued',
      withPhotos,
    }));
    setTasks(newTasks);
    setIsProcessing(true);

    const CONCURRENCY = Math.max(1, Math.min(100, Math.floor(concurrency) || 1));
    let index = 0;

    const runWorker = async () => {
      while (index < newTasks.length) {
        const currentIndex = index++;
        const task = newTasks[currentIndex];
        setTasks(prev => prev.map((t, i) => i === currentIndex ? { ...t, status: 'running' } : t));
        try {
          const res = await analyzeProfile.mutateAsync({ data: {
            username: task.username,
            screenshotDelaySeconds: screenshotDelay,
            gotoTimeoutSeconds: adv.gotoTimeoutSeconds,
            networkIdleTimeoutSeconds: adv.networkIdleTimeoutSeconds,
            consentVisibilityMs: adv.consentVisibilityMs,
            consentClickMs: adv.consentClickMs,
            defaultTimeoutSeconds: adv.defaultTimeoutSeconds,
            viewportWidth: adv.viewportWidth,
            viewportHeight: adv.viewportHeight,
            jpegQuality: adv.jpegQuality,
            autoScroll: flags.autoScroll,
            disableLazyLoad: flags.disableLazyLoad,
            waitForNetworkIdle: flags.waitForNetworkIdle,
            waitForImagesComplete: flags.waitForImagesComplete,
          }});
          setTasks(prev => prev.map((t, i) => i === currentIndex ? { ...t, status: 'done', result: res } : t));
        } catch (err: any) {
          setTasks(prev => prev.map((t, i) => i === currentIndex ? { ...t, status: 'error', error: err?.message || 'Error' } : t));
        }
      }
    };

    const workers = [];
    for (let i = 0; i < CONCURRENCY; i++) workers.push(runWorker());
    await Promise.all(workers);
    setIsProcessing(false);
  };

  // Group completed tasks (keep Task wrapper to preserve withPhotos)
  const groupedTasks = tasks.reduce((acc, task) => {
    if (task.status === 'done' && task.result?.subcategory) {
      const cat = task.result.subcategory;
      if (!acc[cat]) acc[cat] = [];
      acc[cat].push(task);
    }
    return acc;
  }, {} as Record<string, Task[]>);

  const downloadBlob = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExportTxt = () => {
    if (!categories) return;
    let content = "";
    categories.forEach(cat => {
      const items = groupedTasks[cat.id] || [];
      content += `=== ${cat.id} ${cat.name} (${items.length}) ===\n`;
      if (items.length === 0) {
        content += "(пусто)\n";
      } else {
        items.forEach(t => { content += `https://www.instagram.com/${t.result!.username}/\n`; });
      }
      content += "\n";
    });
    downloadBlob(new Blob([content], { type: 'text/plain;charset=utf-8' }), 'instagram-analysis.txt');
  };

  const handleExportExcel = () => {
    if (!categories) return;
    const wb = XLSX.utils.book_new();
    const summary: any[] = [["Категория", "Количество"]];
    const wsSummary = XLSX.utils.aoa_to_sheet(summary);
    XLSX.utils.book_append_sheet(wb, wsSummary, "Сводка");

    categories.forEach(cat => {
      const items = groupedTasks[cat.id] || [];
      summary.push([`${cat.id} ${cat.name}`, items.length]);
      const sheetRows: any[] = [[
        "Username", "Instagram URL", "Источник",
        "Gender", "Age", "Race", "Physique", "Children", "Status", "Style", "Summary"
      ]];
      items.forEach(t => {
        const item = t.result!;
        sheetRows.push([
          item.username,
          `https://www.instagram.com/${item.username}/`,
          item.sourceUrl,
          item.details.gender,
          item.details.ageRange,
          item.details.race,
          item.details.physique,
          item.details.children,
          item.details.relationshipStatus,
          item.details.styleAndContent,
          item.summary,
        ]);
      });
      const ws = XLSX.utils.aoa_to_sheet(sheetRows);
      const safeBase = cat.name.replace(/[\\/?*[\]:]/g, ' ');
      const safeName = `${cat.id} ${safeBase}`.slice(0, 31);
      XLSX.utils.book_append_sheet(wb, ws, safeName);
    });

    XLSX.utils.sheet_add_aoa(wsSummary, summary, { origin: "A1" });
    const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    downloadBlob(
      new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
      'instagram-analysis.xlsx'
    );
  };

  const escapeHtml = (s: string) =>
    String(s ?? '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  const handleExportHtml = () => {
    if (!categories) return;
    const date = new Date().toLocaleString('ru-RU');
    let toc = `<nav class="toc"><strong>Содержание:</strong><ul>`;
    categories.forEach(cat => {
      const items = groupedTasks[cat.id] || [];
      toc += `<li><a href="#cat-${escapeHtml(cat.id)}">${escapeHtml(cat.id)} ${escapeHtml(cat.name)}</a> <span class="count">${items.length}</span></li>`;
    });
    toc += `</ul></nav>`;
    let body = "";
    categories.forEach(cat => {
      const items = groupedTasks[cat.id] || [];
      body += `<section id="cat-${escapeHtml(cat.id)}"><h2><span class="cat-id">${escapeHtml(cat.id)}</span> ${escapeHtml(cat.name)} <span class="count">${items.length}</span></h2>`;
      if (items.length === 0) { body += `<p class="empty">Пусто</p></section>`; return; }
      body += `<table><thead><tr><th>Username</th><th>Instagram</th><th>Gender</th><th>Age</th><th>Race</th><th>Physique</th><th>Children</th><th>Status</th><th>Style</th><th>Summary</th></tr></thead><tbody>`;
      items.forEach(t => {
        const item = t.result!;
        const url = `https://www.instagram.com/${item.username}/`;
        body += `<tr>
  <td>@${escapeHtml(item.username)}</td>
  <td><a href="${escapeHtml(url)}" target="_blank" rel="noreferrer">${escapeHtml(url)}</a></td>
  <td>${escapeHtml(item.details.gender)}</td>
  <td>${escapeHtml(item.details.ageRange)}</td>
  <td>${escapeHtml(item.details.race)}</td>
  <td>${escapeHtml(item.details.physique)}</td>
  <td>${escapeHtml(item.details.children)}</td>
  <td>${escapeHtml(item.details.relationshipStatus)}</td>
  <td>${escapeHtml(item.details.styleAndContent)}</td>
  <td>${escapeHtml(item.summary)}</td>
</tr>`;
      });
      body += `</tbody></table></section>`;
    });
    body = toc + body;

    const html = `<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8" />
<title>Instagram Analysis — ${escapeHtml(date)}</title>
<style>
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background:#0b0b0f; color:#e7e7ea; margin:0; padding:24px; max-width:1400px; margin-left:auto; margin-right:auto; }
  h1 { font-size:20px; margin:0 0 4px; color:#7aa2ff; text-transform:uppercase; letter-spacing:.1em; }
  .meta { color:#8a8a93; font-size:12px; margin-bottom:24px; }
  .toc { background:#13131a; border:1px solid #25252e; border-radius:8px; padding:16px 20px; margin-bottom:32px; }
  .toc strong { color:#a8acb6; font-size:11px; text-transform:uppercase; letter-spacing:.1em; }
  .toc ul { list-style:none; padding:0; margin:10px 0 0; columns:2; column-gap:24px; }
  .toc li { padding:4px 0; font-size:13px; break-inside:avoid; display:flex; justify-content:space-between; gap:12px; }
  section { margin-bottom:32px; scroll-margin-top:16px; }
  h2 { font-size:15px; padding:8px 12px; background:#15151c; border:1px solid #25252e; border-radius:6px; display:flex; align-items:center; gap:10px; }
  .cat-id { font-family: ui-monospace, "SF Mono", Menlo, monospace; color:#7aa2ff; font-size:13px; background:#0b0b0f; padding:2px 6px; border-radius:4px; border:1px solid #25252e; }
  .count { background:#25252e; color:#cdd0d6; font-size:12px; padding:2px 8px; border-radius:10px; font-weight:600; margin-left:auto; }
  .empty { color:#5a5a63; font-style:italic; font-size:12px; padding:12px; text-align:center; border:1px dashed #25252e; border-radius:6px; margin:8px 0 0; }
  table { width:100%; border-collapse:collapse; font-size:12px; margin-top:8px; }
  th, td { text-align:left; padding:8px 10px; border-bottom:1px solid #1f1f27; vertical-align:top; }
  th { background:#15151c; color:#a8acb6; text-transform:uppercase; font-size:10px; letter-spacing:.08em; }
  tr:hover td { background:#13131a; }
  a { color:#7aa2ff; text-decoration:none; }
  a:hover { text-decoration:underline; }
</style>
</head>
<body>
<h1>Insta-Analyzer — Classification Report</h1>
<div class="meta">Сгенерировано: ${escapeHtml(date)}</div>
${body || '<p>Нет результатов.</p>'}
</body>
</html>`;

    downloadBlob(new Blob([html], { type: 'text/html;charset=utf-8' }), 'instagram-analysis.html');
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-6 font-mono text-sm">
      <div className="max-w-6xl mx-auto space-y-6">
        <header className="flex justify-between items-center pb-4 border-b border-border">
          <div>
            <h1 className="text-xl font-bold uppercase tracking-wider text-primary">INSTA-ANALYZER</h1>
            <p className="text-muted-foreground text-xs uppercase tracking-widest mt-1">Classification Engine v1.0</p>
          </div>
          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={!categories || Object.keys(groupedTasks).length === 0}
                  data-testid="button-export-all"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Экспорт
                  <ChevronDown className="w-3 h-3 ml-2 opacity-60" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="font-mono text-xs">
                <DropdownMenuItem onClick={handleExportTxt} data-testid="export-txt">
                  <FileText className="w-4 h-4 mr-2" />
                  TXT (ссылки)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExportExcel} data-testid="export-xlsx">
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  Excel (.xlsx)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExportHtml} data-testid="export-html">
                  <FileCode className="w-4 h-4 mr-2" />
                  HTML отчёт
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="col-span-1 md:col-span-4 space-y-4">
            <Card>
              <CardHeader className="py-4">
                <CardTitle className="text-sm font-semibold uppercase text-muted-foreground">Ввод профилей</CardTitle>
                <CardDescription className="text-xs">Введите юзернеймы или ссылки, по одному на строку.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="username&#10;https://www.instagram.com/another_user/"
                  className="min-h-[200px] resize-y bg-input/50 font-mono text-xs"
                  data-testid="textarea-usernames"
                  disabled={isProcessing}
                />

                <PresetBar
                  presets={allPresets}
                  selectedId={selectedId}
                  onSelect={setSelectedId}
                  onReset={handleResetCurrent}
                  isReadOnly={isReadOnlyPreset}
                  disabled={isProcessing}
                />

                <div className="flex items-center justify-between gap-3">
                  <Label htmlFor="concurrency-input" className="text-xs uppercase tracking-wider text-muted-foreground whitespace-nowrap">
                    Потоки (1–100)
                  </Label>
                  <Input
                    id="concurrency-input"
                    type="number"
                    min={1}
                    max={100}
                    value={concurrency}
                    onChange={(e) => {
                      const v = parseInt(e.target.value, 10);
                      setConcurrency(Number.isNaN(v) ? 1 : Math.max(1, Math.min(100, v)));
                    }}
                    disabled={isProcessing || isReadOnlyPreset}
                    className="w-20 h-8 bg-input/50 font-mono text-xs text-center"
                    data-testid="input-concurrency"
                  />
                </div>
                <div className="flex items-center justify-between gap-3">
                  <Label htmlFor="delay-input" className="text-xs uppercase tracking-wider text-muted-foreground whitespace-nowrap">
                    Ожидание перед скрином, сек (0–600)
                  </Label>
                  <Input
                    id="delay-input"
                    type="number"
                    min={0}
                    max={600}
                    value={screenshotDelay}
                    onChange={(e) => {
                      const v = parseInt(e.target.value, 10);
                      setScreenshotDelay(Number.isNaN(v) ? 0 : Math.max(0, Math.min(600, v)));
                    }}
                    disabled={isProcessing || isReadOnlyPreset}
                    className="w-20 h-8 bg-input/50 font-mono text-xs text-center"
                    data-testid="input-screenshot-delay"
                  />
                </div>
                <div className="space-y-2 border border-border rounded-md p-3 bg-muted/20">
                  <p className="text-[10px] uppercase text-muted-foreground tracking-wider">Полнота загрузки (тест)</p>
                  <FlagCheckbox id="flag-autoscroll" label="п1: авто-скролл перед скрином"
                    checked={flags.autoScroll} onChange={(v) => setFlags((s: PresetFlags) => ({ ...s, autoScroll: v }))}
                    disabled={isProcessing || isReadOnlyPreset} />
                  <FlagCheckbox id="flag-disable-lazy" label="п2: отключить lazy-load у <img>"
                    checked={flags.disableLazyLoad} onChange={(v) => setFlags((s: PresetFlags) => ({ ...s, disableLazyLoad: v }))}
                    disabled={isProcessing || isReadOnlyPreset} />
                  <FlagCheckbox id="flag-networkidle" label="п3: ждать networkidle на goto"
                    checked={flags.waitForNetworkIdle} onChange={(v) => setFlags((s: PresetFlags) => ({ ...s, waitForNetworkIdle: v }))}
                    disabled={isProcessing || isReadOnlyPreset} />
                  <FlagCheckbox id="flag-imgs-complete" label="п4: ждать img.complete && naturalWidth"
                    checked={flags.waitForImagesComplete} onChange={(v) => setFlags((s: PresetFlags) => ({ ...s, waitForImagesComplete: v }))}
                    disabled={isProcessing || isReadOnlyPreset} />
                </div>
                <Collapsible open={advOpen} onOpenChange={setAdvOpen}>
                  <CollapsibleTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="w-full justify-between font-mono text-xs uppercase tracking-wider"
                      data-testid="button-toggle-advanced"
                    >
                      <span className="flex items-center gap-2">
                        {advOpen ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                        Расширенные настройки
                      </span>
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="mt-3 space-y-2 border border-border rounded-md p-3 bg-muted/20">
                    <p className="text-[10px] uppercase text-muted-foreground tracking-wider">Тайминги (Playwright)</p>
                    <NumField label="Таймаут goto, сек" value={adv.gotoTimeoutSeconds} min={5} max={600}
                      onChange={v => setAdv((s: PresetAdvanced) => ({ ...s, gotoTimeoutSeconds: v }))} disabled={isProcessing || isReadOnlyPreset} testId="adv-goto" />
                    <NumField label="networkidle, сек (0=выкл)" value={adv.networkIdleTimeoutSeconds} min={0} max={300}
                      onChange={v => setAdv((s: PresetAdvanced) => ({ ...s, networkIdleTimeoutSeconds: v }))} disabled={isProcessing || isReadOnlyPreset} testId="adv-netidle" />
                    <NumField label="Дефолт таймаут, сек" value={adv.defaultTimeoutSeconds} min={5} max={600}
                      onChange={v => setAdv((s: PresetAdvanced) => ({ ...s, defaultTimeoutSeconds: v }))} disabled={isProcessing || isReadOnlyPreset} testId="adv-deftimeout" />
                    <NumField label="Cookie isVisible, мс" value={adv.consentVisibilityMs} min={50} max={10000}
                      onChange={v => setAdv((s: PresetAdvanced) => ({ ...s, consentVisibilityMs: v }))} disabled={isProcessing || isReadOnlyPreset} testId="adv-cookie-vis" />
                    <NumField label="Cookie click, мс" value={adv.consentClickMs} min={100} max={15000}
                      onChange={v => setAdv((s: PresetAdvanced) => ({ ...s, consentClickMs: v }))} disabled={isProcessing || isReadOnlyPreset} testId="adv-cookie-click" />
                    <p className="text-[10px] uppercase text-muted-foreground tracking-wider pt-2">Скриншот</p>
                    <NumField label="Ширина viewport, px" value={adv.viewportWidth} min={320} max={7680}
                      onChange={v => setAdv((s: PresetAdvanced) => ({ ...s, viewportWidth: v }))} disabled={isProcessing || isReadOnlyPreset} testId="adv-vw" />
                    <NumField label="Высота viewport, px" value={adv.viewportHeight} min={320} max={7680}
                      onChange={v => setAdv((s: PresetAdvanced) => ({ ...s, viewportHeight: v }))} disabled={isProcessing || isReadOnlyPreset} testId="adv-vh" />
                    <NumField label="JPEG качество (10-100)" value={adv.jpegQuality} min={10} max={100}
                      onChange={v => setAdv((s: PresetAdvanced) => ({ ...s, jpegQuality: v }))} disabled={isProcessing || isReadOnlyPreset} testId="adv-jpeg" />
                  </CollapsibleContent>
                </Collapsible>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    className="uppercase font-bold tracking-wider"
                    onClick={() => runAnalysis(false)}
                    disabled={isProcessing || !input.trim()}
                    data-testid="button-start-analysis"
                  >
                    {isProcessing ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> ...</> : "Запустить анализ"}
                  </Button>
                  <Button
                    variant="secondary"
                    className="uppercase font-bold tracking-wider"
                    onClick={() => runAnalysis(true)}
                    disabled={isProcessing || !input.trim()}
                    data-testid="button-start-analysis-photos"
                  >
                    {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Camera className="w-4 h-4 mr-2" /> Анализ (с фото)</>}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {tasks.length > 0 && (
              <Card>
                <CardHeader className="py-4">
                  <CardTitle className="text-sm font-semibold uppercase text-muted-foreground">Очередь</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[300px] pr-4">
                    <div className="space-y-2">
                      {tasks.map((task, i) => (
                        <div key={i} className="flex items-center justify-between py-1.5 border-b border-border/50 last:border-0" data-testid={`row-task-${task.username}`}>
                          <span className="truncate flex-1 font-mono text-xs pr-4">{task.username}</span>
                          <span className="flex-shrink-0 flex items-center">
                            {task.status === 'queued' && <Clock className="w-3 h-3 text-muted-foreground" data-testid={`icon-queued-${task.username}`} />}
                            {task.status === 'running' && <Loader2 className="w-3 h-3 animate-spin text-primary" data-testid={`icon-running-${task.username}`} />}
                            {task.status === 'done' && <CheckCircle2 className="w-3 h-3 text-green-500" data-testid={`icon-done-${task.username}`} />}
                            {task.status === 'error' && <XCircle className="w-3 h-3 text-destructive" data-testid={`icon-error-${task.username}`} />}
                          </span>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            )}
          </div>

          <div className="col-span-1 md:col-span-8 space-y-4">
            <h2 className="text-sm font-semibold uppercase text-muted-foreground mb-4">Результаты классификации</h2>

            {!categories ? (
              <div className="flex justify-center p-12 text-muted-foreground">
                <Loader2 className="w-6 h-6 animate-spin" />
              </div>
            ) : (
              categories.map(cat => {
                const items = groupedTasks[cat.id] || [];
                return (
                  <CategorySection key={cat.id} category={cat} items={items} />
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function PresetBar({ presets, selectedId, onSelect, onReset, isReadOnly, disabled }: {
  presets: Preset[];
  selectedId: string;
  onSelect: (id: string) => void;
  onReset: () => void;
  isReadOnly: boolean;
  disabled?: boolean;
}) {
  if (presets.length === 0) return null;
  return (
    <div className="space-y-2 border border-border rounded-md p-3 bg-muted/20">
      <div className="flex items-center justify-between">
        <p className="text-[10px] uppercase text-muted-foreground tracking-wider">Пресеты настроек</p>
        {!isReadOnly && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-6 px-2 text-[10px]"
            onClick={onReset}
            disabled={disabled}
            data-testid="button-reset-current-preset"
            title="Сбросить этот пресет к значениям по умолчанию"
          >
            <RotateCcw className="w-3 h-3 mr-1" />
            Сброс
          </Button>
        )}
      </div>
      <div className="grid grid-cols-4 gap-1">
        {presets.map(p => (
          <button
            key={p.id}
            type="button"
            onClick={() => onSelect(p.id)}
            disabled={disabled}
            className={`text-[11px] px-2 py-1.5 rounded border transition-colors flex items-center justify-center gap-1 ${
              p.id === selectedId
                ? 'bg-primary/20 border-primary text-primary'
                : 'bg-background border-border text-foreground/70 hover:border-primary/50'
            } disabled:opacity-50`}
            data-testid={`preset-${p.id}`}
          >
            {p.readOnly && <Lock className="w-2.5 h-2.5 opacity-60" />}
            <span className="truncate">{p.name}</span>
          </button>
        ))}
      </div>
      <p className="text-[10px] text-muted-foreground italic">
        {isReadOnly
          ? 'Пресет «По умолчанию» защищён от изменений. Выберите пресет 1–3 для редактирования.'
          : 'Изменения в полях ниже автоматически сохраняются в этот пресет.'}
      </p>
    </div>
  );
}

function CategorySection({ category, items }: { category: any, items: Task[] }) {
  const [open, setOpen] = useState(true);

  const handleCopyLinks = (e: React.MouseEvent) => {
    e.stopPropagation();
    const text = items.map(t => `https://www.instagram.com/${t.result!.username}/`).join('\n');
    navigator.clipboard.writeText(text);
  };

  return (
    <Collapsible open={open} onOpenChange={setOpen} className="border border-border rounded-md bg-card/50 overflow-hidden" data-testid={`category-section-${category.id}`}>
      <div className="flex items-center justify-between p-3 bg-card border-b border-border">
        <CollapsibleTrigger className="flex items-center gap-2 hover:text-primary transition-colors flex-1 text-left" data-testid={`trigger-category-${category.id}`}>
          {open ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          <span className="font-semibold text-sm">{category.name}</span>
          <Badge variant="secondary" className="ml-2 font-mono">{items.length}</Badge>
        </CollapsibleTrigger>

        {items.length > 0 && (
          <Button variant="ghost" size="icon" onClick={handleCopyLinks} title="Скопировать ссылки" className="h-8 w-8 ml-2" data-testid={`button-copy-links-${category.id}`}>
            <Copy className="w-4 h-4" />
          </Button>
        )}
      </div>

      <CollapsibleContent>
        {items.length === 0 ? (
          <div className="p-4 text-xs text-muted-foreground italic text-center">Пусто</div>
        ) : (
          <div className="divide-y divide-border/50">
            {items.map((task, idx) => (
              <ResultRow key={`${task.result!.username}-${idx}`} item={task.result!} withPhotos={task.withPhotos} />
            ))}
          </div>
        )}
      </CollapsibleContent>
    </Collapsible>
  );
}

function ResultRow({ item, withPhotos }: { item: AnalyzeResult; withPhotos: boolean }) {
  const [detailsOpen, setDetailsOpen] = useState(false);
  const screenshots = item.screenshots ?? [];

  return (
    <div className="p-3 hover:bg-muted/30 transition-colors" data-testid={`result-row-${item.username}`}>
      <div className="flex items-start gap-4">
        {withPhotos && screenshots.length > 0 ? (
          <div className="w-24 flex-shrink-0 flex flex-col gap-1">
            {screenshots.map((url, i) => (
              <a
                key={url}
                href={url}
                target="_blank"
                rel="noreferrer"
                className="block group"
                data-testid={`link-screenshot-${item.username}-${i}`}
                title={`Открыть полное фото ${i + 1}`}
              >
                <img
                  src={url}
                  alt={`Скрин ${i + 1} профиля @${item.username}`}
                  className="w-24 h-32 object-cover object-top rounded border border-border group-hover:border-primary transition-colors bg-muted"
                  loading="lazy"
                />
                <span className="block text-[10px] text-center text-muted-foreground group-hover:text-primary mt-0.5">
                  Фото {i + 1}
                </span>
              </a>
            ))}
          </div>
        ) : null}

        <div className="flex-1 min-w-0 space-y-1">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <a href={item.instagramUrl} target="_blank" rel="noreferrer" className="text-primary hover:underline font-bold text-sm truncate" data-testid={`link-instagram-${item.username}`}>
              @{item.username}
            </a>
            <div className="flex items-center gap-3 text-xs">
              {!withPhotos && screenshots.length > 0 && (
                <>
                  {screenshots.map((url, i) => (
                    <a
                      key={url}
                      href={url}
                      target="_blank"
                      rel="noreferrer"
                      className="text-muted-foreground hover:text-primary"
                      data-testid={`link-screenshot-${item.username}-${i}`}
                      title={`Открыть фото ${i + 1}`}
                    >
                      Фото {i + 1}
                    </a>
                  ))}
                </>
              )}
              <a href={item.sourceUrl} target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-foreground" data-testid={`link-source-${item.username}`}>
                Источник
              </a>
            </div>
          </div>

          <p className="text-xs text-foreground/80 line-clamp-2">{item.summary}</p>

          <Collapsible open={detailsOpen} onOpenChange={setDetailsOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="link" size="sm" className="h-6 p-0 text-xs text-muted-foreground hover:text-primary mt-1" data-testid={`button-details-${item.username}`}>
                {detailsOpen ? "Скрыть детали" : "Показать детали"}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-2 text-xs bg-muted/50 p-2 rounded border border-border/50 grid grid-cols-1 md:grid-cols-2 gap-2">
              <div><span className="text-muted-foreground">Gender:</span> {item.details.gender}</div>
              <div><span className="text-muted-foreground">Age:</span> {item.details.ageRange}</div>
              <div><span className="text-muted-foreground">Race:</span> {item.details.race}</div>
              <div><span className="text-muted-foreground">Physique:</span> {item.details.physique}</div>
              <div><span className="text-muted-foreground">Children:</span> {item.details.children}</div>
              <div><span className="text-muted-foreground">Status:</span> {item.details.relationshipStatus}</div>
              <div className="col-span-full"><span className="text-muted-foreground">Style:</span> {item.details.styleAndContent}</div>
            </CollapsibleContent>
          </Collapsible>
        </div>
      </div>
    </div>
  );
}

function FlagCheckbox({ id, label, checked, onChange, disabled }: {
  id: string;
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <div className="flex items-center gap-2">
      <Checkbox
        id={id}
        checked={checked}
        onCheckedChange={(v) => onChange(v === true)}
        disabled={disabled}
        data-testid={`checkbox-${id}`}
      />
      <Label
        htmlFor={id}
        className="text-[11px] text-foreground/80 cursor-pointer leading-tight"
      >
        {label}
      </Label>
    </div>
  );
}

function NumField({ label, value, min, max, onChange, disabled, testId }: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
  disabled?: boolean;
  testId: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <Label className="text-[11px] text-muted-foreground whitespace-nowrap flex-1">{label}</Label>
      <Input
        type="number"
        min={min}
        max={max}
        value={value}
        onChange={(e) => {
          const v = parseInt(e.target.value, 10);
          onChange(Number.isNaN(v) ? min : Math.max(min, Math.min(max, v)));
        }}
        disabled={disabled}
        className="w-24 h-7 bg-input/50 font-mono text-xs text-center"
        data-testid={`input-${testId}`}
      />
    </div>
  );
}
