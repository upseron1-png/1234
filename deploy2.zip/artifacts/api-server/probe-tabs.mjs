import { chromium } from "playwright";
const exe = process.env.REPLIT_PLAYWRIGHT_CHROMIUM_EXECUTABLE;
const browser = await chromium.launch({ headless: true, executablePath: exe, args:["--no-sandbox","--disable-blink-features=AutomationControlled"] });
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const p = await ctx.newPage();
await p.goto("https://insta-stories-viewer.com/natgeo/", { waitUntil: "domcontentloaded" });
await p.waitForTimeout(8000);
const info = await p.evaluate(() => {
  const all = Array.from(document.querySelectorAll("*"));
  const matches = all.filter(el => /^(Publications|Публикации|Stories)$/.test((el.textContent||"").trim())).slice(0,20);
  return matches.map(el => ({ tag: el.tagName, cls: el.className?.toString?.()?.slice(0,80), txt: el.textContent.trim().slice(0,40), href: el.getAttribute("href") }));
});
console.log(JSON.stringify(info, null, 2));
await browser.close();
