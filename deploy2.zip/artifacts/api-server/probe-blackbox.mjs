import { chromium } from 'playwright';

const browser = await chromium.launch({
  headless: true,
  executablePath: process.env.REPLIT_PLAYWRIGHT_CHROMIUM_EXECUTABLE,
  args: ['--no-sandbox','--disable-setuid-sandbox','--disable-dev-shm-usage','--disable-gpu','--disable-blink-features=AutomationControlled'],
});
const ctx = await browser.newContext({
  viewport: { width: 1440, height: 900 },
  userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  extraHTTPHeaders: { 'Accept-Language': 'en-US,en;q=0.9' },
});
const page = await ctx.newPage();
await page.goto('https://app.blackbox.ai/', { waitUntil: 'domcontentloaded', timeout: 45000 });
await page.waitForTimeout(12000);

console.log('TITLE:', await page.title());
console.log('URL:', page.url());

const html = await page.content();
console.log('HTML length:', html.length);
console.log('---HTML head 1500---');
console.log(html.slice(0, 1500));

const fileInputs = await page.locator("input[type='file']").count();
const textareas = await page.locator("textarea").count();
const editables = await page.locator("[contenteditable='true']").count();
const textboxes = await page.locator("[role='textbox']").count();
console.log('file inputs:', fileInputs, 'textareas:', textareas, 'editables:', editables, 'textboxes:', textboxes);

await page.screenshot({ path: '/tmp/blackbox-probe.png', fullPage: false });
console.log('screenshot saved /tmp/blackbox-probe.png');

await browser.close();
