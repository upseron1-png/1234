import { Router, type IRouter } from "express";
import { TestProxyBody, TestProxyResponse } from "@workspace/api-zod";
import { getProxyBrowser, normalizeProxy } from "../lib/browser";

const router: IRouter = Router();

router.post("/proxy-test", async (req, res): Promise<void> => {
  req.setTimeout(60_000);
  res.setTimeout(60_000);

  const parsed = TestProxyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json(
      TestProxyResponse.parse({ ok: false, error: parsed.error.message }),
    );
    return;
  }

  const proxyCfg = normalizeProxy(
    parsed.data.server,
    parsed.data.username,
    parsed.data.password,
  );
  if (!proxyCfg) {
    res.json(
      TestProxyResponse.parse({
        ok: false,
        error: "Неверный формат прокси. Ожидается host:port или scheme://host:port.",
      }),
    );
    return;
  }

  let context: Awaited<ReturnType<Awaited<ReturnType<typeof getProxyBrowser>>["newContext"]>> | null = null;
  try {
    const browser = await getProxyBrowser();
    context = await browser.newContext({ proxy: proxyCfg });
    const page = await context.newPage();
    page.setDefaultTimeout(20_000);

    const response = await page.goto("https://api.ipify.org?format=json", {
      waitUntil: "domcontentloaded",
      timeout: 20_000,
    });

    if (!response || !response.ok()) {
      res.json(
        TestProxyResponse.parse({
          ok: false,
          error: `HTTP ${response?.status() ?? "?"}`,
        }),
      );
      return;
    }

    const body = await response.json().catch(() => null) as { ip?: string } | null;
    const ip = body?.ip;
    if (!ip) {
      res.json(
        TestProxyResponse.parse({
          ok: false,
          error: "Не удалось получить IP",
        }),
      );
      return;
    }

    req.log.info({ proxy: proxyCfg.server, ip }, "Proxy test OK");
    res.json(TestProxyResponse.parse({ ok: true, ip }));
  } catch (err) {
    const message = err instanceof Error ? err.message : "Proxy test failed";
    req.log.warn({ err, proxy: proxyCfg.server }, "Proxy test failed");
    res.json(TestProxyResponse.parse({ ok: false, error: message }));
  } finally {
    if (context) await context.close().catch(() => {});
  }
});

export default router;
