import { Router, type IRouter } from "express";
import { loadPresets, savePresets, resetPreset } from "../lib/presets-storage";
import { logger } from "../lib/logger";

const router: IRouter = Router();

router.get("/presets", async (_req, res) => {
  try {
    const state = await loadPresets();
    res.json(state);
  } catch (err: any) {
    logger.error({ err }, "Failed to load presets");
    res.status(500).json({ error: "Failed to load presets" });
  }
});

router.put("/presets", async (req, res) => {
  try {
    const editable = Array.isArray(req.body?.editable) ? req.body.editable : [];
    const state = await savePresets(editable);
    res.json(state);
  } catch (err: any) {
    logger.error({ err }, "Failed to save presets");
    res.status(500).json({ error: "Failed to save presets" });
  }
});

router.post("/presets/:id/reset", async (req, res) => {
  try {
    const state = await resetPreset(req.params.id);
    if (!state) {
      res.status(404).json({ error: "Preset not found" });
      return;
    }
    res.json(state);
  } catch (err: any) {
    logger.error({ err }, "Failed to reset preset");
    res.status(500).json({ error: "Failed to reset preset" });
  }
});

export default router;
