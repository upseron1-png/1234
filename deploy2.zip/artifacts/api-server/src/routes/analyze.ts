import { Router, type IRouter } from "express";
import {
  AnalyzeProfileBody,
  AnalyzeProfileResponse,
  ListCategoriesResponse,
} from "@workspace/api-zod";
import {
  getCategoryMap,
  getCategoryName,
  type AnalysisVersion,
} from "../lib/categories";
import { captureProfileScreenshots } from "../lib/screenshots";
import { analyzeProfileWithVision } from "../lib/analyze-vision";
import { analyzeProfileWithBlackbox } from "../lib/analyze-blackbox";
import { persistScreenshots } from "../lib/screenshot-storage";

const VISION_PROVIDER = (process.env["VISION_PROVIDER"] ?? "blackbox").toLowerCase();

const router: IRouter = Router();

router.get("/categories", (req, res) => {
  const v = (req.query["version"] as string | undefined) === "v2" ? "v2" : "v1";
  res.json(ListCategoriesResponse.parse(getCategoryMap(v)));
});

router.post("/analyze", async (req, res): Promise<void> => {
  // Allow up to 15 minutes for slow profiles / large screenshot delays (cap is 600s delay + processing).
  req.setTimeout(900_000);
  res.setTimeout(900_000);

  const parsed = AnalyzeProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const username = parsed.data.username
    .trim()
    .replace(/^@/, "")
    .replace(/^https?:\/\/(www\.)?instagram\.com\//i, "")
    .replace(/^https?:\/\/(www\.)?insta-stories-viewer\.com\//i, "")
    .replace(/\/.*$/, "");

  if (!/^[A-Za-z0-9._]{1,40}$/.test(username)) {
    res.status(400).json({ error: `Invalid username: "${username}"` });
    return;
  }

  req.log.info({ username }, "Starting profile analysis");

  const version: AnalysisVersion =
    parsed.data.analysisVersion === "v2" ? "v2" : "v1";

  try {
    const { sourceUrl, screenshots } = await captureProfileScreenshots(
      username,
      {
        delaySeconds: parsed.data.screenshotDelaySeconds,
        gotoTimeoutSeconds: parsed.data.gotoTimeoutSeconds,
        networkIdleTimeoutSeconds: parsed.data.networkIdleTimeoutSeconds,
        consentVisibilityMs: parsed.data.consentVisibilityMs,
        consentClickMs: parsed.data.consentClickMs,
        defaultTimeoutSeconds: parsed.data.defaultTimeoutSeconds,
        viewportWidth: parsed.data.viewportWidth,
        viewportHeight: parsed.data.viewportHeight,
        jpegQuality: parsed.data.jpegQuality,
        autoScroll: parsed.data.autoScroll,
        disableLazyLoad: parsed.data.disableLazyLoad,
        waitForNetworkIdle: parsed.data.waitForNetworkIdle,
        waitForImagesComplete: parsed.data.waitForImagesComplete,
        proxyServer: parsed.data.proxyServer,
        proxyUsername: parsed.data.proxyUsername,
        proxyPassword: parsed.data.proxyPassword,
      },
    );
    req.log.info(
      { username, count: screenshots.length, version },
      "Captured screenshots",
    );

    const analysis =
      VISION_PROVIDER === "openai"
        ? await analyzeProfileWithVision(username, screenshots, version)
        : await analyzeProfileWithBlackbox(username, screenshots, version);
    req.log.info(
      {
        username,
        subcategory: analysis.subcategory,
        provider: VISION_PROVIDER,
        version,
      },
      "Vision analysis complete",
    );

    const payload = {
      username,
      instagramUrl: `https://www.instagram.com/${username}/`,
      sourceUrl,
      category: analysis.category,
      subcategory: analysis.subcategory,
      categoryName: getCategoryName(analysis.subcategory, version),
      summary: analysis.summary,
      details: analysis.details,
      screenshots: await persistScreenshots(username, screenshots),
    };

    res.json(AnalyzeProfileResponse.parse(payload));
  } catch (err) {
    req.log.error({ err, username }, "Profile analysis failed");
    const message = err instanceof Error ? err.message : "Analysis failed";
    res.status(500).json({ error: message });
  }
});

export default router;
