import { Router, type IRouter } from "express";
import healthRouter from "./health";
import analyzeRouter from "./analyze";
import presetsRouter from "./presets";
import proxyTestRouter from "./proxy-test";

const router: IRouter = Router();

router.use(healthRouter);
router.use(analyzeRouter);
router.use(presetsRouter);
router.use(proxyTestRouter);

export default router;
