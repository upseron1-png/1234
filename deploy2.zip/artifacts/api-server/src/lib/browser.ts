import { chromium, type Browser, type LaunchOptions } from "playwright";

export interface ProxyConfig {
  server: string;
  username?: string;
  password?: string;
}

let defaultBrowserPromise: Promise<Browser> | null = null;
let proxyBrowserPromise: Promise<Browser> | null = null;

const COMMON_ARGS = [
  "--no-sandbox",
  "--disable-setuid-sandbox",
  "--disable-dev-shm-usage",
  "--disable-gpu",
  "--disable-blink-features=AutomationControlled",
];

function buildLaunchOptions(): LaunchOptions {
  const executablePath = process.env["REPLIT_PLAYWRIGHT_CHROMIUM_EXECUTABLE"];
  return {
    headless: true,
    executablePath: executablePath || undefined,
    args: [...COMMON_ARGS],
  };
}

export async function getBrowser(): Promise<Browser> {
  if (!defaultBrowserPromise) {
    defaultBrowserPromise = chromium.launch(buildLaunchOptions()).catch((err) => {
      defaultBrowserPromise = null;
      throw err;
    });
  }
  return defaultBrowserPromise;
}

/**
 * Launches a browser whose contexts may override the proxy on a per-context basis.
 * Chromium requires a launch-time proxy for `context.proxy` to take effect.
 * We use the `per-context` placeholder so the actual proxy is set on `newContext()`.
 */
export async function getProxyBrowser(): Promise<Browser> {
  if (!proxyBrowserPromise) {
    proxyBrowserPromise = chromium
      .launch({ ...buildLaunchOptions(), proxy: { server: "per-context" } })
      .catch((err) => {
        proxyBrowserPromise = null;
        throw err;
      });
  }
  return proxyBrowserPromise;
}

/**
 * Normalizes a user-entered proxy string into a Playwright-compatible
 * { server, username, password }. Returns null if the input is invalid.
 *
 * Accepts:
 *   1.2.3.4:8080
 *   http://1.2.3.4:8080
 *   socks5://1.2.3.4:1080
 *   user:pass@1.2.3.4:8080
 */
export function normalizeProxy(
  rawServer: string | undefined,
  rawUser?: string,
  rawPass?: string,
): ProxyConfig | null {
  if (!rawServer) return null;
  let s = String(rawServer).trim();
  if (!s) return null;

  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(s)) {
    s = `http://${s}`;
  }

  let url: URL;
  try {
    url = new URL(s);
  } catch {
    return null;
  }

  const scheme = url.protocol.replace(":", "").toLowerCase();
  if (!["http", "https", "socks5", "socks5h"].includes(scheme)) return null;
  if (!url.hostname) return null;

  const port = url.port ? `:${url.port}` : "";
  const server = `${scheme === "socks5h" ? "socks5" : scheme}://${url.hostname}${port}`;

  const username =
    (rawUser ?? "").trim() ||
    (url.username ? decodeURIComponent(url.username) : "");
  const password =
    (rawPass ?? "") ||
    (url.password ? decodeURIComponent(url.password) : "");

  const cfg: ProxyConfig = { server };
  if (username) cfg.username = username;
  if (password) cfg.password = password;
  return cfg;
}
