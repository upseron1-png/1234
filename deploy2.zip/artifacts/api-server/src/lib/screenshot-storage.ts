import { mkdir, writeFile, readdir, stat, unlink } from "node:fs/promises";
import { join, resolve } from "node:path";
import { randomUUID } from "node:crypto";
import { logger } from "./logger";

export const SCREENSHOTS_DIR = resolve(
  process.cwd(),
  process.env["SCREENSHOTS_DIR"] ?? "screenshots",
);

const MAX_AGE_MS = 1000 * 60 * 60 * 24 * 7;
const MAX_FILES = 5000;

let initPromise: Promise<void> | null = null;

async function ensureDir(): Promise<void> {
  if (!initPromise) {
    initPromise = mkdir(SCREENSHOTS_DIR, { recursive: true }).then(
      () => undefined,
    );
  }
  await initPromise;
}

function safeUsername(username: string): string {
  return username.replace(/[^A-Za-z0-9._-]/g, "_").slice(0, 40);
}

export async function persistScreenshots(
  username: string,
  buffers: Buffer[],
): Promise<string[]> {
  await ensureDir();
  const stamp = Date.now();
  const safe = safeUsername(username);
  const urls: string[] = [];
  for (let i = 0; i < buffers.length; i++) {
    const file = `${safe}-${stamp}-${randomUUID().slice(0, 8)}-${i}.jpg`;
    const path = join(SCREENSHOTS_DIR, file);
    await writeFile(path, buffers[i]!);
    urls.push(`/api/screenshots/${file}`);
  }
  return urls;
}

let cleanupRunning = false;
export async function cleanupOldScreenshots(): Promise<void> {
  if (cleanupRunning) return;
  cleanupRunning = true;
  try {
    await ensureDir();
    const entries = await readdir(SCREENSHOTS_DIR);
    const now = Date.now();
    const stats = await Promise.all(
      entries.map(async (name) => {
        try {
          const s = await stat(join(SCREENSHOTS_DIR, name));
          return { name, mtimeMs: s.mtimeMs, size: s.size };
        } catch {
          return null;
        }
      }),
    );
    const valid = stats.filter((s): s is NonNullable<typeof s> => s !== null);
    let removed = 0;

    // Remove anything older than MAX_AGE_MS.
    for (const s of valid) {
      if (now - s.mtimeMs > MAX_AGE_MS) {
        await unlink(join(SCREENSHOTS_DIR, s.name)).catch(() => undefined);
        removed++;
      }
    }

    // If still too many, evict oldest first.
    if (valid.length - removed > MAX_FILES) {
      const sorted = valid
        .filter((s) => now - s.mtimeMs <= MAX_AGE_MS)
        .sort((a, b) => a.mtimeMs - b.mtimeMs);
      const overflow = sorted.length - MAX_FILES;
      for (let i = 0; i < overflow; i++) {
        await unlink(join(SCREENSHOTS_DIR, sorted[i]!.name)).catch(
          () => undefined,
        );
        removed++;
      }
    }

    if (removed > 0) {
      logger.info({ removed }, "Pruned old screenshots");
    }
  } finally {
    cleanupRunning = false;
  }
}

// Periodic background cleanup (every 6h).
setInterval(() => {
  cleanupOldScreenshots().catch((err) =>
    logger.warn({ err }, "Screenshot cleanup failed"),
  );
}, 1000 * 60 * 60 * 6).unref();
