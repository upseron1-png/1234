export interface CategoryEntry {
  id: string;
  name: string;
}

export type AnalysisVersion = "v1" | "v2";

export const CATEGORY_MAP: CategoryEntry[] = [
  { id: "1.1", name: "Дочки (Свободна/Лесби/Неизвестно)" },
  { id: "1.2", name: "Дочки (В отношениях с мужчиной)" },
  { id: "1.3", name: "Дочки (Замужем)" },
  { id: "2.1", name: "Мускулы (Черная, Свободна/Лесби)" },
  { id: "2.2", name: "Мускулы (Черная, В отношениях)" },
  { id: "2.3", name: "Мускулы (Белая/Другая, Свободна/Лесби)" },
  { id: "2.4", name: "Мускулы (Белая/Другая, В отношениях)" },
  { id: "3.1", name: "Стиль/Трейты (Черная, Свободна/Лесби)" },
  { id: "3.2", name: "Стиль/Трейты (Черная, В отношениях)" },
  { id: "3.3", name: "Стиль/Трейты (Белая/Другая, Свободна/Лесби)" },
  { id: "3.4", name: "Стиль/Трейты (Белая/Другая, В отношениях)" },
  { id: "4.1", name: "Общий (Черная, Свободна/Лесби)" },
  { id: "4.2", name: "Общий (Черная, В отношениях)" },
  { id: "4.3", name: "Общий (Белая/Другая, Свободна/Лесби)" },
  { id: "4.4", name: "Общий (Белая/Другая, В отношениях)" },
  { id: "5", name: "Убранные (Мужчины/Сыновья/Замужем без дочерей)" },
];

export const CATEGORY_MAP_V2: CategoryEntry[] = [
  { id: "1.1", name: "Дочки (Свободна/Лесби/Неизвестно)" },
  { id: "1.2", name: "Дочки (В отношениях с мужчиной)" },
  { id: "1.3", name: "Дочки (Замужем)" },
  { id: "2.1", name: "Мускулы (Черная, Свободна/Лесби)" },
  { id: "2.2", name: "Мускулы (Черная, В отношениях)" },
  { id: "2.3", name: "Мускулы (Белая/Другая, Свободна/Лесби)" },
  { id: "2.4", name: "Мускулы (Белая/Другая, В отношениях)" },
  { id: "3.1", name: "Стиль/Трейты (Черная, Свободна/Лесби)" },
  { id: "3.2", name: "Стиль/Трейты (Черная, В отношениях)" },
  { id: "3.3", name: "Стиль/Трейты (Белая/Другая, Свободна/Лесби)" },
  { id: "3.4", name: "Стиль/Трейты (Белая/Другая, В отношениях)" },
  { id: "4.1", name: "Спорт/Модель (Черная, Свободна/Лесби/Неизвестно)" },
  { id: "4.2", name: "Спорт/Модель (Черная, В отношениях)" },
  { id: "4.3", name: "Спорт/Модель (Белая/Другая, Свободна/Лесби/Неизвестно)" },
  { id: "4.4", name: "Спорт/Модель (Белая/Другая, В отношениях)" },
  { id: "5.1", name: "Общий (Черная, Свободна/Лесби)" },
  { id: "5.2", name: "Общий (Черная, В отношениях)" },
  { id: "5.3", name: "Общий (Белая/Другая, Свободна/Лесби)" },
  { id: "5.4", name: "Общий (Белая/Другая, В отношениях)" },
  { id: "6", name: "Убранные (Мужчины/Сыновья/Замужем без дочерей)" },
];

export function getCategoryMap(version: AnalysisVersion = "v1"): CategoryEntry[] {
  return version === "v2" ? CATEGORY_MAP_V2 : CATEGORY_MAP;
}

export function getCategoryName(
  id: string,
  version: AnalysisVersion = "v1",
): string {
  const map = getCategoryMap(version);
  const entry = map.find((c) => c.id === id);
  if (entry) return entry.name;
  return version === "v2"
    ? "Общий (Белая/Другая, Свободна/Лесби)"
    : "Общий (Белая/Другая, Свободна/Лесби)";
}

export function normalizeCategoryId(
  raw: unknown,
  version: AnalysisVersion = "v1",
): string {
  const map = getCategoryMap(version);
  const validIds = new Set(map.map((c) => c.id));
  const fallback = version === "v2" ? "5.3" : "4.3";
  if (typeof raw !== "string") return fallback;
  const trimmed = raw.trim();
  if (validIds.has(trimmed)) return trimmed;
  return fallback;
}

export function topLevelCategory(id: string): string {
  const top = id.split(".")[0];
  return top ?? id;
}
