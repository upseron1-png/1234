import type { BrowserContext, Page } from "playwright-core";
import { logger } from "./logger";
import { getBrowser, getProxyBrowser, normalizeProxy } from "./browser";

export interface ScreenshotOptions {
  delaySeconds?: number;
  gotoTimeoutSeconds?: number;
  networkIdleTimeoutSeconds?: number;
  consentVisibilityMs?: number;
  consentClickMs?: number;
  defaultTimeoutSeconds?: number;
  viewportWidth?: number;
  viewportHeight?: number;
  jpegQuality?: number;
  // Experimental "loading completeness" toggles (see UI checkboxes п1–п4)
  autoScroll?: boolean;
  disableLazyLoad?: boolean;
  waitForNetworkIdle?: boolean;
  waitForImagesComplete?: boolean;
  // Optional outbound proxy
  proxyServer?: string;
  proxyUsername?: string;
  proxyPassword?: string;
}

const DEFAULTS = {
  delaySeconds: 32,
  gotoTimeoutSeconds: 45,
  networkIdleTimeoutSeconds: 0,
  consentVisibilityMs: 500,
  consentClickMs: 2_000,
  defaultTimeoutSeconds: 45,
  viewportWidth: 1600,
  viewportHeight: 3200,
  jpegQuality: 85,
};

type Tab = "stories" | "publications";

const TAB_SELECTORS: Record<Tab, string[]> = {
  stories: [
    'a:has-text("Stories")',
    'button:has-text("Stories")',
    '[role="tab"]:has-text("Stories")',
    'a:has-text("Истории")',
    'button:has-text("Истории")',
  ],
  publications: [
    'a:has-text("Publications")',
    'button:has-text("Publications")',
    '[role="tab"]:has-text("Publications")',
    'a:has-text("Posts")',
    'button:has-text("Posts")',
    'a:has-text("Публикации")',
    'button:has-text("Публикации")',
  ],
};

// `null` means: don't switch tabs at all — capture whatever the site loaded by default.
type TabSelection = Tab | null;

function clamp(v: number | undefined, min: number, max: number, fallback: number): number {
  const n = typeof v === "number" && Number.isFinite(v) ? v : fallback;
  return Math.max(min, Math.min(max, n));
}

interface ResolvedConfig {
  delayMs: number;
  gotoTimeoutMs: number;
  networkIdleMs: number;
  consentVisibilityMs: number;
  consentClickMs: number;
  defaultTimeoutMs: number;
  viewportWidth: number;
  viewportHeight: number;
  jpegQuality: number;
  autoScroll: boolean;
  disableLazyLoad: boolean;
  waitForNetworkIdle: boolean;
  waitForImagesComplete: boolean;
}

function resolveConfig(options: ScreenshotOptions): ResolvedConfig {
  return {
    delayMs: clamp(options.delaySeconds, 0, 600, DEFAULTS.delaySeconds) * 1000,
    gotoTimeoutMs:
      clamp(options.gotoTimeoutSeconds, 5, 600, DEFAULTS.gotoTimeoutSeconds) *
      1000,
    networkIdleMs:
      clamp(
        options.networkIdleTimeoutSeconds,
        0,
        300,
        DEFAULTS.networkIdleTimeoutSeconds,
      ) * 1000,
    consentVisibilityMs: clamp(
      options.consentVisibilityMs,
      50,
      10_000,
      DEFAULTS.consentVisibilityMs,
    ),
    consentClickMs: clamp(
      options.consentClickMs,
      100,
      15_000,
      DEFAULTS.consentClickMs,
    ),
    defaultTimeoutMs:
      clamp(
        options.defaultTimeoutSeconds,
        5,
        600,
        DEFAULTS.defaultTimeoutSeconds,
      ) * 1000,
    viewportWidth: Math.round(
      clamp(options.viewportWidth, 320, 7680, DEFAULTS.viewportWidth),
    ),
    viewportHeight: Math.round(
      clamp(options.viewportHeight, 320, 7680, DEFAULTS.viewportHeight),
    ),
    jpegQuality: Math.round(
      clamp(options.jpegQuality, 10, 100, DEFAULTS.jpegQuality),
    ),
    autoScroll: !!options.autoScroll,
    disableLazyLoad: !!options.disableLazyLoad,
    waitForNetworkIdle: !!options.waitForNetworkIdle,
    waitForImagesComplete: !!options.waitForImagesComplete,
  };
}

async function dismissConsent(page: Page, cfg: ResolvedConfig): Promise<void> {
  for (const sel of [
    'button:has-text("Accept")',
    'button:has-text("Принять")',
    'button:has-text("Agree")',
    'button:has-text("Got it")',
    'button:has-text("OK")',
    'button[aria-label="Consent"]',
  ]) {
    try {
      const btn = page.locator(sel).first();
      if (await btn.isVisible({ timeout: cfg.consentVisibilityMs })) {
        await btn.click({ timeout: cfg.consentClickMs }).catch(() => undefined);
      }
    } catch {
      // ignore
    }
  }
}

async function clickTab(page: Page, tab: Tab): Promise<boolean> {
  for (const sel of TAB_SELECTORS[tab]) {
    try {
      const el = page.locator(sel).first();
      if (await el.isVisible({ timeout: 1_000 })) {
        await el.click({ timeout: 2_000 });
        return true;
      }
    } catch {
      // try next selector
    }
  }
  return false;
}

async function captureTab(
  context: BrowserContext,
  sourceUrl: string,
  tab: TabSelection,
  cfg: ResolvedConfig,
): Promise<Buffer> {
  const page = await context.newPage();
  page.setDefaultTimeout(cfg.defaultTimeoutMs);

  try {
    await page.goto(sourceUrl, {
      waitUntil: cfg.waitForNetworkIdle ? "networkidle" : "domcontentloaded",
      timeout: cfg.gotoTimeoutMs,
    });

    if (cfg.networkIdleMs > 0) {
      await page
        .waitForLoadState("networkidle", { timeout: cfg.networkIdleMs })
        .catch(() => undefined);
    }

    await dismissConsent(page, cfg);

    if (tab !== null) {
      const tabClicked = await clickTab(page, tab);
      logger.info({ tab, tabClicked }, "captureTab: tab switch");

      // Give the page a small moment to swap content after the tab click.
      if (tabClicked) {
        await page.waitForTimeout(800);
      }
    } else {
      logger.info({ tab: "default" }, "captureTab: no tab switch");
    }

    // п2: force eager loading on every <img> + promote data-src/srcset to src
    if (cfg.disableLazyLoad) {
      await page
        .evaluate(() => {
          const imgs = Array.from(document.querySelectorAll("img"));
          for (const img of imgs) {
            try {
              img.loading = "eager";
              img.decoding = "sync";
              const ds =
                img.getAttribute("data-src") ||
                img.getAttribute("data-original") ||
                img.getAttribute("data-lazy-src");
              if (ds && (!img.src || img.src !== ds)) img.src = ds;
              const dss =
                img.getAttribute("data-srcset") ||
                img.getAttribute("data-lazy-srcset");
              if (dss && !img.srcset) img.srcset = dss;
            } catch {
              // ignore per-element failures
            }
          }
        })
        .catch(() => undefined);
    }

    // п1: scroll page top → bottom → top in steps to trigger any deferred loads
    if (cfg.autoScroll) {
      await page
        .evaluate(async () => {
          const sleep = (ms: number) =>
            new Promise<void>((r) => setTimeout(r, ms));
          const step = 600;
          const max = Math.max(
            document.body.scrollHeight,
            document.documentElement.scrollHeight,
          );
          for (let y = 0; y < max; y += step) {
            window.scrollTo(0, y);
            await sleep(300);
          }
          window.scrollTo(0, max);
          await sleep(500);
          window.scrollTo(0, 0);
          await sleep(300);
        })
        .catch(() => undefined);
    }

    // Single user-controlled wait before taking the screenshot.
    await page.waitForTimeout(cfg.delayMs);

    // п4: explicitly wait until every <img> reports complete && naturalWidth > 0
    if (cfg.waitForImagesComplete) {
      await page
        .evaluate(
          (timeoutMs) =>
            new Promise<void>((resolve) => {
              const start = Date.now();
              const check = () => {
                const imgs = Array.from(document.images);
                const pending = imgs.filter(
                  (i) => !(i.complete && i.naturalWidth > 0),
                );
                if (pending.length === 0) return resolve();
                if (Date.now() - start > timeoutMs) return resolve();
                setTimeout(check, 250);
              };
              check();
            }),
          // cap the wait so we never hang the request
          Math.min(300_000, Math.max(5_000, cfg.delayMs || 15_000)),
        )
        .catch(() => undefined);
    }

    return await page.screenshot({
      type: "jpeg",
      quality: cfg.jpegQuality,
      fullPage: true,
    });
  } finally {
    await page.close().catch((err) => {
      logger.warn({ err, tab }, "Failed to close playwright page");
    });
  }
}

export async function captureProfileScreenshots(
  username: string,
  options: ScreenshotOptions = {},
): Promise<{ sourceUrl: string; screenshots: Buffer[] }> {
  const cfg = resolveConfig(options);

  const sourceUrl = `https://insta-stories-viewer.com/${encodeURIComponent(
    username,
  )}/`;

  const proxyCfg = normalizeProxy(
    options.proxyServer,
    options.proxyUsername,
    options.proxyPassword,
  );

  logger.info(
    { username, cfg, proxyServer: proxyCfg?.server ?? null },
    "captureProfileScreenshots: configured",
  );

  const browser = proxyCfg ? await getProxyBrowser() : await getBrowser();
  const context = await browser.newContext({
    viewport: { width: cfg.viewportWidth, height: cfg.viewportHeight },
    deviceScaleFactor: 1,
    userAgent:
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    ...(proxyCfg ? { proxy: proxyCfg } : {}),
  });

  try {
    // Two pages captured fully in parallel:
    //   #1 — whatever the site loads by default (no tab click), like the
    //        original behaviour, so the user can debug the inconsistent default.
    //   #2 — explicitly switched to the Publications tab.
    const [defaultShot, publicationsShot] = await Promise.all([
      captureTab(context, sourceUrl, null, cfg),
      captureTab(context, sourceUrl, "publications", cfg),
    ]);

    return {
      sourceUrl,
      screenshots: [defaultShot, publicationsShot],
    };
  } finally {
    await context.close().catch((err) => {
      logger.warn({ err }, "Failed to close playwright context");
    });
  }
}
