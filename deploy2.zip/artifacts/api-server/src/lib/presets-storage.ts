import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { logger } from "./logger";

export interface PresetAdvanced {
  gotoTimeoutSeconds: number;
  networkIdleTimeoutSeconds: number;
  consentVisibilityMs: number;
  consentClickMs: number;
  defaultTimeoutSeconds: number;
  viewportWidth: number;
  viewportHeight: number;
  jpegQuality: number;
}

export interface PresetFlags {
  autoScroll: boolean;
  disableLazyLoad: boolean;
  waitForNetworkIdle: boolean;
  waitForImagesComplete: boolean;
}

export interface ProxySettings {
  enabled: boolean;
  server: string;
  username: string;
  password: string;
}

export interface Preset {
  id: string;
  name: string;
  readOnly: boolean;
  concurrency: number;
  screenshotDelaySeconds: number;
  adv: PresetAdvanced;
  flags: PresetFlags;
  proxy: ProxySettings;
}

export interface PresetsState {
  default: Preset;
  editable: Preset[];
}

const PRESETS_FILE = resolve(
  process.cwd(),
  process.env["PRESETS_FILE"] ?? "data/presets.json",
);

const DEFAULT_ADV: PresetAdvanced = {
  gotoTimeoutSeconds: 45,
  networkIdleTimeoutSeconds: 0,
  consentVisibilityMs: 500,
  consentClickMs: 2000,
  defaultTimeoutSeconds: 45,
  viewportWidth: 1600,
  viewportHeight: 3200,
  jpegQuality: 85,
};

const DEFAULT_FLAGS: PresetFlags = {
  autoScroll: false,
  disableLazyLoad: false,
  waitForNetworkIdle: false,
  waitForImagesComplete: false,
};

const DEFAULT_PROXY: ProxySettings = {
  enabled: false,
  server: "",
  username: "",
  password: "",
};

export const DEFAULT_PRESET: Preset = {
  id: "default",
  name: "По умолчанию",
  readOnly: true,
  concurrency: 5,
  screenshotDelaySeconds: 32,
  adv: DEFAULT_ADV,
  flags: DEFAULT_FLAGS,
  proxy: DEFAULT_PROXY,
};

function makeEditableDefault(id: string, name: string): Preset {
  return {
    id,
    name,
    readOnly: false,
    concurrency: DEFAULT_PRESET.concurrency,
    screenshotDelaySeconds: DEFAULT_PRESET.screenshotDelaySeconds,
    adv: { ...DEFAULT_ADV },
    flags: { ...DEFAULT_FLAGS },
    proxy: { ...DEFAULT_PROXY },
  };
}

export const EDITABLE_IDS = ["preset1", "preset2", "preset3"] as const;
const EDITABLE_NAMES: Record<string, string> = {
  preset1: "Пресет 1",
  preset2: "Пресет 2",
  preset3: "Пресет 3",
};

function freshState(): PresetsState {
  return {
    default: { ...DEFAULT_PRESET, adv: { ...DEFAULT_ADV }, flags: { ...DEFAULT_FLAGS } },
    editable: EDITABLE_IDS.map((id) => makeEditableDefault(id, EDITABLE_NAMES[id]!)),
  };
}

function sanitizePreset(input: unknown, id: string, fallbackName: string): Preset {
  const base = makeEditableDefault(id, fallbackName);
  if (!input || typeof input !== "object") return base;
  const p = input as Partial<Preset>;
  const adv = (p.adv ?? {}) as Partial<PresetAdvanced>;
  const flags = (p.flags ?? {}) as Partial<PresetFlags>;
  const proxy = (p.proxy ?? {}) as Partial<ProxySettings>;
  const num = (v: unknown, d: number) =>
    typeof v === "number" && Number.isFinite(v) ? Math.floor(v) : d;
  const bool = (v: unknown, d: boolean) => (typeof v === "boolean" ? v : d);
  const str = (v: unknown, d: string) => (typeof v === "string" ? v : d);
  return {
    id,
    name: typeof p.name === "string" && p.name.trim() ? p.name.slice(0, 60) : fallbackName,
    readOnly: false,
    concurrency: Math.max(1, Math.min(100, num(p.concurrency, base.concurrency))),
    screenshotDelaySeconds: Math.max(
      0,
      Math.min(600, num(p.screenshotDelaySeconds, base.screenshotDelaySeconds)),
    ),
    adv: {
      gotoTimeoutSeconds: Math.max(5, Math.min(600, num(adv.gotoTimeoutSeconds, base.adv.gotoTimeoutSeconds))),
      networkIdleTimeoutSeconds: Math.max(0, Math.min(300, num(adv.networkIdleTimeoutSeconds, base.adv.networkIdleTimeoutSeconds))),
      consentVisibilityMs: Math.max(50, Math.min(10000, num(adv.consentVisibilityMs, base.adv.consentVisibilityMs))),
      consentClickMs: Math.max(100, Math.min(15000, num(adv.consentClickMs, base.adv.consentClickMs))),
      defaultTimeoutSeconds: Math.max(5, Math.min(600, num(adv.defaultTimeoutSeconds, base.adv.defaultTimeoutSeconds))),
      viewportWidth: Math.max(320, Math.min(7680, num(adv.viewportWidth, base.adv.viewportWidth))),
      viewportHeight: Math.max(320, Math.min(7680, num(adv.viewportHeight, base.adv.viewportHeight))),
      jpegQuality: Math.max(10, Math.min(100, num(adv.jpegQuality, base.adv.jpegQuality))),
    },
    flags: {
      autoScroll: bool(flags.autoScroll, base.flags.autoScroll),
      disableLazyLoad: bool(flags.disableLazyLoad, base.flags.disableLazyLoad),
      waitForNetworkIdle: bool(flags.waitForNetworkIdle, base.flags.waitForNetworkIdle),
      waitForImagesComplete: bool(flags.waitForImagesComplete, base.flags.waitForImagesComplete),
    },
    proxy: {
      enabled: bool(proxy.enabled, base.proxy.enabled),
      server: str(proxy.server, base.proxy.server).trim(),
      username: str(proxy.username, base.proxy.username),
      password: str(proxy.password, base.proxy.password),
    },
  };
}

let cache: PresetsState | null = null;

async function persist(state: PresetsState): Promise<void> {
  await mkdir(dirname(PRESETS_FILE), { recursive: true });
  await writeFile(PRESETS_FILE, JSON.stringify(state, null, 2), "utf8");
}

export async function loadPresets(): Promise<PresetsState> {
  if (cache) return cache;
  try {
    const raw = await readFile(PRESETS_FILE, "utf8");
    const parsed = JSON.parse(raw) as { editable?: unknown[] };
    const fresh = freshState();
    const editableInput = Array.isArray(parsed.editable) ? parsed.editable : [];
    fresh.editable = EDITABLE_IDS.map((id, idx) =>
      sanitizePreset(editableInput[idx], id, EDITABLE_NAMES[id]!),
    );
    cache = fresh;
  } catch (err: any) {
    if (err && err.code !== "ENOENT") {
      logger.warn({ err }, "Failed to read presets file, using defaults");
    }
    cache = freshState();
    await persist(cache).catch((e) => logger.warn({ err: e }, "Failed to write initial presets"));
  }
  return cache;
}

export async function savePresets(editable: unknown[]): Promise<PresetsState> {
  const fresh = freshState();
  fresh.editable = EDITABLE_IDS.map((id, idx) =>
    sanitizePreset(editable[idx], id, EDITABLE_NAMES[id]!),
  );
  cache = fresh;
  await persist(fresh);
  return fresh;
}

export async function resetPreset(id: string): Promise<PresetsState | null> {
  if (!EDITABLE_IDS.includes(id as (typeof EDITABLE_IDS)[number])) return null;
  const state = await loadPresets();
  state.editable = state.editable.map((p) =>
    p.id === id ? makeEditableDefault(id, EDITABLE_NAMES[id]!) : p,
  );
  cache = state;
  await persist(state);
  return state;
}
