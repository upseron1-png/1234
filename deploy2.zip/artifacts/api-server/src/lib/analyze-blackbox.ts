import { writeFile, unlink, mkdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import { getBrowser } from "./browser";
import { normalizeCategoryId, type AnalysisVersion } from "./categories";
import { logger } from "./logger";
import type { VisionAnalysis } from "./analyze-vision";

const PROMPT_V1 = `Ты эксперт по визуальному анализу публичных Instagram-профилей. \
На скриншотах ниже — страница https://insta-stories-viewer.com/{username}/ (зеркало Instagram-страницы). \
Отнеси профиль строго к одной категории из карты, на основе ТОЛЬКО видимого.

КАРТА КАТЕГОРИЙ:
1.1 Дочки (Свободна/Лесби/Неизвестно)
1.2 Дочки (В отношениях с мужчиной)
1.3 Дочки (Замужем)
2.1 Мускулы (Черная, Свободна/Лесби)
2.2 Мускулы (Черная, В отношениях)
2.3 Мускулы (Белая/Другая, Свободна/Лесби)
2.4 Мускулы (Белая/Другая, В отношениях)
3.1 Стиль/Трейты (Черная, Свободна/Лесби)
3.2 Стиль/Трейты (Черная, В отношениях)
3.3 Стиль/Трейты (Белая/Другая, Свободна/Лесби)
3.4 Стиль/Трейты (Белая/Другая, В отношениях)
4.1 Общий (Черная, Свободна/Лесби)
4.2 Общий (Черная, В отношениях)
4.3 Общий (Белая/Другая, Свободна/Лесби)
4.4 Общий (Белая/Другая, В отношениях)
5   Убранные (Мужчины/Сыновья/Замужем без дочерей)

ОТСЕВ (5): мужчина; либо у женщины сыновей >= дочерей; либо замужем БЕЗ дочерей.
КАТЕГОРИЯ 1 (приоритет): есть дочь / дочерей > сыновей. .1 свободна/лесби/неизв., .2 в отн. с мужчиной, .3 замужем.
КАТЕГОРИЯ 2 (мускулы): фитнес/бодибилдер/выраженная мускулатура. *.1/*.2 чёрная, *.3/*.4 белая/другая.
КАТЕГОРИЯ 3 (стиль): большой бюст (>3.5), >=180см, роскошь, домина, латекс, готика, кожа, сапоги-чулки, сатанистка, супер-модель.
КАТЕГОРИЯ 4: всё прочее. Раса × отношения с мужчиной как в 2/3.
Если расу не видно — "белая/другая" (.3/.4). Бренди/йога/танцы — НЕ мускулы.

ВЕРНИ СТРОГО один JSON-объект, без markdown, без пояснений до или после:
{"subcategory":"X.Y","summary":"краткий вердикт + категория","details":{"gender":"","ageRange":"","race":"","physique":"","children":"","styleAndContent":"","relationshipStatus":""}}`;

const PROMPT_V2 = `Ты эксперт по визуальному анализу публичных Instagram-профилей. \
На скриншотах ниже — страница https://insta-stories-viewer.com/{username}/ (зеркало Instagram-страницы). \
Отнеси профиль строго к одной категории из карты, на основе ТОЛЬКО видимого.

КАРТА КАТЕГОРИЙ:
1.1 Дочки (Свободна/Лесби/Неизвестно)
1.2 Дочки (В отношениях с мужчиной)
1.3 Дочки (Замужем)
2.1 Мускулы (Черная, Свободна/Лесби)
2.2 Мускулы (Черная, В отношениях)
2.3 Мускулы (Белая/Другая, Свободна/Лесби)
2.4 Мускулы (Белая/Другая, В отношениях)
3.1 Стиль/Трейты (Черная, Свободна/Лесби)
3.2 Стиль/Трейты (Черная, В отношениях)
3.3 Стиль/Трейты (Белая/Другая, Свободна/Лесби)
3.4 Стиль/Трейты (Белая/Другая, В отношениях)
4.1 Спорт/Модель (Черная, Свободна/Лесби/Неизвестно)
4.2 Спорт/Модель (Черная, В отношениях)
4.3 Спорт/Модель (Белая/Другая, Свободна/Лесби/Неизвестно)
4.4 Спорт/Модель (Белая/Другая, В отношениях)
5.1 Общий (Черная, Свободна/Лесби)
5.2 Общий (Черная, В отношениях)
5.3 Общий (Белая/Другая, Свободна/Лесби)
5.4 Общий (Белая/Другая, В отношениях)
6   Убранные (Мужчины/Сыновья/Замужем без дочерей)

ПРАВИЛА:

ОТСЕВ (категория 6): мужчина; ИЛИ у женщины сыновей >= дочерей; ИЛИ замужем БЕЗ дочерей.
Замужняя оставляется ТОЛЬКО если у неё есть дочь и дочерей строго больше чем сыновей, и сыновей не больше одного.

КАТЕГОРИЯ 1 (ПРИОРИТЕТ — исключает из 2/3/4/5): есть дочь, дочерей > сыновей.
1.1 свободна / в отношениях с девушкой (лесби) / отношения неизвестны
1.2 не замужем, в романтических или серьёзных отношениях с мужчиной
1.3 замужем

КАТЕГОРИЯ 2 (Мускулы) — одно из:
- бодибилдерша; мускулистая (выраженная мускулатура);
- фитнес-мастер; спортивный тренер;
- ходит в зал, видны мускулистые ноги/руки/пресс/попа;
- атлетка; портретит амазонку; телесная сила.
Лёгкий спорт (бег, йога, танцы) — НЕ мускулы.

КАТЕГОРИЯ 3 (Стиль/Трейты) — одно из:
- большой бюст (от 3.5);
- очень высокая (от 180 см);
- очень богатая;
- домина / Госпожа (БДСМ, фемдом, феминизм, гинархия, матриархат);
- латексная одежда; готический стиль; сексуальный стиль (кожа/латекс);
- сексуальные сапоги (сапоги-чулки, стрипы, на платформе, ботфорты, ботфорты на шпильке);
- танцовщица в сексуальных сапогах любого цвета (особенно чёрные/розовые/красные);
- сатанистка.

КАТЕГОРИЯ 4 (Спорт/Модель) — одно из:
- спортивная девушка модельной внешности;
- спортсменка БЕЗ выраженной мускулатуры (модельный спорт);
- спортивная фигура (ноги/руки/пресс/попа) при модельной внешности.
Лёгкий спорт (бег/танцы) без модельной внешности — НЕ сюда.

КАТЕГОРИЯ 5 (Общий): всё, что не подошло в 1–4.

Подкатегории .1/.2/.3/.4 для категорий 2, 3, 4, 5:
.1 — чернокожая, свободна/лесби/неизв.
.2 — чернокожая, в отношениях с мужчиной
.3 — белая/другая раса, свободна/лесби/неизв.
.4 — белая/другая раса, в отношениях с мужчиной
Если расу не видно — считаем "белая/другая" (.3/.4).

ВЕРНИ СТРОГО один JSON-объект, без markdown, без пояснений до или после:
{"subcategory":"X.Y","summary":"краткий вердикт + категория","details":{"gender":"","ageRange":"","race":"","physique":"","children":"","styleAndContent":"","relationshipStatus":""}}`;

function getPrompt(version: AnalysisVersion): string {
  return version === "v2" ? PROMPT_V2 : PROMPT_V1;
}

interface ParsedJson {
  subcategory?: unknown;
  summary?: unknown;
  details?: Record<string, unknown>;
}

function safeString(v: unknown, fallback = "Неизвестно"): string {
  return typeof v === "string" && v.trim().length > 0 ? v : fallback;
}

function extractJson(text: string): ParsedJson {
  if (!text) return {};
  // Strip markdown code fences.
  const cleaned = text.replace(/```(?:json)?/gi, "").replace(/```/g, "");
  // Find the first balanced {...} block.
  const start = cleaned.indexOf("{");
  if (start < 0) return {};
  let depth = 0;
  for (let i = start; i < cleaned.length; i++) {
    const ch = cleaned[i];
    if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) {
        const candidate = cleaned.slice(start, i + 1);
        try {
          return JSON.parse(candidate) as ParsedJson;
        } catch {
          return {};
        }
      }
    }
  }
  return {};
}

// --- semaphore for max concurrent Blackbox sessions ---
const MAX_CONCURRENCY = Math.max(
  1,
  parseInt(process.env["BLACKBOX_CONCURRENCY"] ?? "10", 10) || 10,
);
let active = 0;
const waitQueue: Array<() => void> = [];

async function acquireSlot(): Promise<void> {
  if (active < MAX_CONCURRENCY) {
    active++;
    return;
  }
  await new Promise<void>((resolve) => waitQueue.push(resolve));
  active++;
}

function releaseSlot(): void {
  active--;
  const next = waitQueue.shift();
  if (next) next();
}

// --- temp file helpers (Playwright setInputFiles wants paths) ---
async function writeTempImages(buffers: Buffer[]): Promise<string[]> {
  const dir = join(tmpdir(), "blackbox-uploads");
  await mkdir(dir, { recursive: true });
  const paths: string[] = [];
  for (let i = 0; i < buffers.length; i++) {
    const p = join(dir, `${randomUUID()}-${i}.jpg`);
    await writeFile(p, buffers[i]!);
    paths.push(p);
  }
  return paths;
}

async function cleanupTempImages(paths: string[]): Promise<void> {
  for (const p of paths) {
    await unlink(p).catch(() => undefined);
  }
}

export async function analyzeProfileWithBlackbox(
  username: string,
  screenshots: Buffer[],
  version: AnalysisVersion = "v1",
): Promise<VisionAnalysis> {
  await acquireSlot();
  const tempPaths = await writeTempImages(screenshots);
  const browser = await getBrowser();
  const context = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
    userAgent:
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    extraHTTPHeaders: {
      "Accept-Language": "en-US,en;q=0.9,ru;q=0.8",
    },
  });

  try {
    const page = await context.newPage();
    page.setDefaultTimeout(30_000);

    await page.goto("https://app.blackbox.ai/", {
      waitUntil: "domcontentloaded",
      timeout: 45_000,
    });

    // Give the SPA time to mount.
    await page.waitForTimeout(12_000);

    // Try to dismiss any cookie / consent overlays.
    for (const sel of [
      'button:has-text("Accept")',
      'button:has-text("Got it")',
      'button:has-text("OK")',
      'button:has-text("Agree")',
      'button[aria-label*="close" i]',
    ]) {
      try {
        const btn = page.locator(sel).first();
        if (await btn.isVisible({ timeout: 500 })) {
          await btn.click({ timeout: 1_500 }).catch(() => undefined);
        }
      } catch {
        // ignore
      }
    }

    // First: locate the chat textarea (placeholder like "Message Blackbox").
    // We need it BEFORE upload so we can verify the page is interactive.
    const chatInput = page
      .locator(
        'textarea[placeholder*="Message" i], textarea[placeholder*="Blackbox" i], textarea',
      )
      .first();
    await chatInput.waitFor({ state: "visible", timeout: 25_000 });

    // Find file input. May be hidden — query via DOM.
    const fileInput = page.locator("input[type='file']").first();
    await fileInput.waitFor({ state: "attached", timeout: 20_000 });

    // Try multi-upload first; fall back to single.
    try {
      await fileInput.setInputFiles(tempPaths);
    } catch (err) {
      logger.warn(
        { err, username },
        "blackbox multi-upload failed, falling back to single",
      );
      await fileInput.setInputFiles(tempPaths[0]!);
    }

    // Wait a moment for upload preview to register.
    await page.waitForTimeout(5_000);

    // Type the prompt and submit.
    const promptText = getPrompt(version).replace(/\n/g, " ");
    try {
      await chatInput.click({ timeout: 5_000 });
    } catch {
      // ignore; we'll still try to set value via JS
    }
    await chatInput.evaluate((el, value) => {
      const textarea = el as HTMLTextAreaElement;
      const setter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype,
        "value",
      )?.set;
      setter?.call(textarea, value);
      textarea.dispatchEvent(new Event("input", { bubbles: true }));
      textarea.dispatchEvent(new Event("change", { bubbles: true }));
    }, promptText);
    await page.waitForTimeout(500);
    await chatInput.focus().catch(() => undefined);

    // Snapshot existing message count BEFORE submitting so we can ignore
    // any pre-existing nodes and the user's own echoed prompt bubble.
    const responseSelector = "div[id*='message'], .prose, [data-message]";
    const initialCount = await page.locator(responseSelector).count();

    await page.keyboard.press("Enter");

    // Poll: wait until message count grew by at least 2 (user bubble +
    // assistant bubble) AND the last (assistant) bubble has stable JSON-like
    // content. Up to 120 seconds.
    const startedAt = Date.now();
    const deadline = startedAt + 120_000;
    let lastText = "";
    let stableSince = 0;

    while (Date.now() < deadline) {
      await page.waitForTimeout(1_500);
      let text = "";
      let count = 0;
      try {
        const items = page.locator(responseSelector);
        count = await items.count();
        // Need at least the user bubble + assistant bubble appended.
        if (count >= initialCount + 2) {
          text = (await items.nth(count - 1).innerText()).trim();
        }
      } catch {
        text = "";
      }

      if (text && text === lastText) {
        if (Date.now() - stableSince >= 4_000 && text.includes("{")) {
          break;
        }
      } else {
        lastText = text;
        stableSince = Date.now();
      }
    }

    const elapsed = Date.now() - startedAt;
    if (!lastText || !lastText.includes("{")) {
      throw new Error(
        `blackbox: no JSON response after ${Math.round(elapsed / 1000)}s`,
      );
    }

    logger.info(
      { username, elapsedMs: elapsed, len: lastText.length },
      "blackbox response captured",
    );

    const parsed = extractJson(lastText);
    if (!parsed.subcategory) {
      logger.warn(
        { username, raw: lastText.slice(0, 1000) },
        "blackbox: JSON parse produced no subcategory",
      );
    }
    const subcategory = normalizeCategoryId(parsed.subcategory, version);
    const top = subcategory.split(".")[0] ?? subcategory;
    const details = parsed.details ?? {};

    return {
      category: top,
      subcategory,
      summary: safeString(parsed.summary, "Анализ не удалось интерпретировать."),
      details: {
        gender: safeString(details["gender"]),
        ageRange: safeString(details["ageRange"]),
        race: safeString(details["race"]),
        physique: safeString(details["physique"]),
        children: safeString(details["children"]),
        styleAndContent: safeString(details["styleAndContent"]),
        relationshipStatus: safeString(details["relationshipStatus"]),
      },
    };
  } finally {
    await context.close().catch((err) => {
      logger.warn({ err }, "Failed to close blackbox context");
    });
    await cleanupTempImages(tempPaths);
    releaseSlot();
  }
}
