import { openai } from "@workspace/integrations-openai-ai-server";
import { normalizeCategoryId, type AnalysisVersion } from "./categories";

export interface VisionAnalysis {
  category: string;
  subcategory: string;
  summary: string;
  details: {
    gender: string;
    ageRange: string;
    race: string;
    physique: string;
    children: string;
    styleAndContent: string;
    relationshipStatus: string;
  };
}

const SYSTEM_PROMPT = `Ты эксперт по визуальному анализу публичных Instagram-профилей. \
Тебе дают скриншоты страницы https://insta-stories-viewer.com/{username}/ — это \
зеркало с открытой Instagram-страницей пользователя (аватар, био, посты, сторис). \
Твоя задача: на основе ТОЛЬКО того, что реально видно на скриншотах, отнести \
профиль к одной категории из карты ниже. Никаких догадок без визуальных оснований.

--- КАРТА КАТЕГОРИЙ ---
1.1: Дочки (Свободна/Лесби/Неизвестно)
1.2: Дочки (В отношениях с мужчиной)
1.3: Дочки (Замужем)
2.1: Мускулы (Черная, Свободна/Лесби)
2.2: Мускулы (Черная, В отношениях)
2.3: Мускулы (Белая/Другая, Свободна/Лесби)
2.4: Мускулы (Белая/Другая, В отношениях)
3.1: Стиль/Трейты (Черная, Свободна/Лесби)
3.2: Стиль/Трейты (Черная, В отношениях)
3.3: Стиль/Трейты (Белая/Другая, Свободна/Лесби)
3.4: Стиль/Трейты (Белая/Другая, В отношениях)
4.1: Общий (Черная, Свободна/Лесби)
4.2: Общий (Черная, В отношениях)
4.3: Общий (Белая/Другая, Свободна/Лесби)
4.4: Общий (Белая/Другая, В отношениях)
5  : Убранные (Мужчины/Сыновья/Замужем без дочерей)

--- ПРАВИЛА ОТСЕВА (категория 5) ---
В категорию 5 попадает профиль, если:
- Профиль однозначно принадлежит мужчине.
- У женщины есть сын (даже если не замужем) И сыновей >= дочерей.
- Замужем И при этом у нее НЕТ дочерей (или дочерей меньше чем сыновей).

В категорию 5 НЕ попадает (нужно классифицировать дальше):
- Замужем, но есть дочь / дочерей больше чем сыновей и сыновей не больше одного.
- Не замужем, без детей вообще.

--- ПРАВИЛА КАТЕГОРИИ 1 (приоритет) ---
Если у девушки есть дочь или дочерей больше чем сыновей — это всегда категория 1
(перекрывает 2/3/4).
- 1.1 — не в романтических/серьезных отношениях с мужчиной (свободна, лесби,
       или семейный статус неизвестен).
- 1.2 — не замужем, но в романтических/серьезных отношениях с мужчиной.
- 1.3 — замужем.

--- ПРАВИЛА КАТЕГОРИИ 2 (мускулы) ---
Только если она НЕ попала в 1. Девушка с выраженной мускулатурой: фитнес-тренерша,
бодибилдерша, атлетка, амазонка, мускулистые руки/ноги/пресс/попа, тяжелые тренировки.
Танцы, легкий спорт, йога — НЕ считаются мускулистыми.
- *.1 / *.2 — темнокожая (черная). .1 свободна/лесби/неизвестно, .2 в отношениях с мужчиной.
- *.3 / *.4 — белая или другая раса (не черная). Те же подкатегории.

--- ПРАВИЛА КАТЕГОРИИ 3 (стиль/трейты) ---
Только если она НЕ попала в 1 и 2. Подходит, если хотя бы одно:
- большой бюст (от ~3.5);
- очень высокая (от 180 см);
- очень богатая (демонстрация роскоши);
- домина / госпожа (BDSM, фемдом, феминизм, гинархия, матриархат);
- латексная одежда; готический стиль; кожаная/латексная сексуальная одежда;
- сексуальные сапоги (сапоги-чулки, стрипы, на платформе, ботфорты, ботфорты на шпильке),
  танцовщица в таких сапогах (особенно черные/розовые/красные);
- сатанистка;
- супер-модель с яркой фигурой.
Подкатегории как в 2 (раса × отношения с мужчиной).

--- КАТЕГОРИЯ 4 ---
Все остальные женщины, не попавшие в 1/2/3 и не отсеянные в 5.
Подкатегории как в 2/3 (раса × отношения с мужчиной).

--- ВАЖНО ---
- "Свободна/Лесби/Неизвестно" объединяются в одну подкатегорию (.1 в списках 2/3/4 и
  1.1 в списке 1).
- "В отношениях с мужчиной" — это и серьезные отношения, и брак (для списков 2/3/4
  они идут в одну подкатегорию .2 / .4).
- Если расу невозможно определить — выбирай "белая/другая" (подкатегории .3/.4).
- Никогда не возвращай subcategory вне списка категорий.
- summary — ОЧЕНЬ короткий вердикт на русском (1 предложение), затем номер категории
  и ее полное название из карты.

Формат ответа: строго один JSON-объект (без markdown, без комментариев) со схемой:
{
  "subcategory": string,   // одна из: 1.1, 1.2, 1.3, 2.1, 2.2, 2.3, 2.4, 3.1, 3.2, 3.3, 3.4, 4.1, 4.2, 4.3, 4.4, 5
  "summary":     string,   // короткий вердикт + категория
  "details": {
    "gender":             string,
    "ageRange":           string,
    "race":               string,  // "Черная" / "Белая" / "Другая" / "Неизвестно"
    "physique":           string,  // мышечная масса, пресс, плечи
    "children":           string,  // признаки детей (коляски, игрушки, лица детей)
    "styleAndContent":    string,  // латекс, готика, ботфорты, спорт и т.п.
    "relationshipStatus": string   // муж на фото, кольца, парень, свободна, лесби
  }
}`;

interface ParsedJson {
  subcategory?: unknown;
  summary?: unknown;
  details?: Record<string, unknown>;
}

function safeString(v: unknown, fallback = "Неизвестно"): string {
  return typeof v === "string" && v.trim().length > 0 ? v : fallback;
}

export async function analyzeProfileWithVision(
  username: string,
  screenshots: Buffer[],
  version: AnalysisVersion = "v1",
): Promise<VisionAnalysis> {
  const imageContent = screenshots.map((buf) => ({
    type: "image_url" as const,
    image_url: {
      url: `data:image/jpeg;base64,${buf.toString("base64")}`,
      detail: "high" as const,
    },
  }));

  const response = await openai.chat.completions.create({
    model: "gpt-5.4",
    max_completion_tokens: 8192,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      {
        role: "user",
        content: [
          {
            type: "text",
            text:
              `Профиль для анализа: @${username}.\n` +
              `Источник: https://insta-stories-viewer.com/${username}/\n` +
              `Проведи глубокий визуальный анализ скриншотов и верни JSON по схеме.`,
          },
          ...imageContent,
        ],
      },
    ],
  });

  const raw = response.choices[0]?.message?.content ?? "";
  let parsed: ParsedJson = {};
  try {
    parsed = JSON.parse(raw) as ParsedJson;
  } catch {
    parsed = {};
  }

  const subcategory = normalizeCategoryId(parsed.subcategory, version);
  const top = subcategory.split(".")[0] ?? subcategory;

  const details = parsed.details ?? {};

  return {
    category: top,
    subcategory,
    summary: safeString(parsed.summary, "Анализ не удалось интерпретировать."),
    details: {
      gender: safeString(details["gender"]),
      ageRange: safeString(details["ageRange"]),
      race: safeString(details["race"]),
      physique: safeString(details["physique"]),
      children: safeString(details["children"]),
      styleAndContent: safeString(details["styleAndContent"]),
      relationshipStatus: safeString(details["relationshipStatus"]),
    },
  };
}
